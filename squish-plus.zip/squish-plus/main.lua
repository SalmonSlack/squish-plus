-- name: Squish+
-- description: Squish+ v1.07\nBy \\#ff8cf2\\Jaygon\n\n\\#dcdcdc\\Squish+ expands on the existing squish feature in SM64, making it more dynamic, more interactive, and more cartoony! Players can now find themselves squished into a variety of poses, all based on the pose they were in the moment they got squashed! This mod adds new sound effects, new squish physics, and new enemy interactions that will leave players flatter than ever before!

local tostring, mod_file_exists, audio_sample_load = tostring, mod_file_exists, audio_sample_load
local AUDIO_EXTENSIONS = { '.ogg', '.mp3' }

---Loads audio samples into a table
---@param prefix string The prefix the files we're loading starts with
---@param len integer How many files to search through
---@return ModAudio[]
local function loadAudioSamples(prefix, len)
    local samples = {}
    for i = 0, len do
        local fileName = prefix .. "_" .. tostring(i)
        -- Checking file name against common audio extensions
        for j = 1, #AUDIO_EXTENSIONS do
            if mod_file_exists("sound/" .. fileName .. AUDIO_EXTENSIONS[j]) then
                local sample = audio_sample_load(fileName .. AUDIO_EXTENSIONS[j])
                table.insert(samples, sample)
                goto continue
            end
        end
        ::continue::
    end
    return samples
end

--- @type ModAudio[]
SPLAT_SOUNDS = loadAudioSamples("splat", 10)

--- @type ModAudio[]
RESTORE_SOUNDS = loadAudioSamples("restore", 10)

-- Modifiable via Mod Menu
DEFAULT_SURFACE_OBJECT_STICK_CHANCE = 0.25 -- 25%
DEFAULT_SQUISH_DEPTH = 0.02 -- How flat the character should be. Going lower than 0.005 causes rubberbanding issues (0.005 - 0.12)
DEFAULT_SPREAD_X = 0.4 -- How much the player's spread value should increase by on the X-axis when squished (0.0 - 1.0, Low values start to shrink Mario's model)
DEFAULT_SPREAD_Z = 0.4 -- How much the player's spread value should increase by on the Z-axis when squished (0.0 - 1.0, Low values start to shrink Mario's model)
DEFAULT_SOUND_VOLUME = 1.2 -- How loud all the custom sound effects will be {0.0, 2.5}
DEFAULT_IS_SMEAR_EFFECT_ENABLED = true
DEFAULT_BASE_SQUISH_DAMAGE = 512 -- One sliver of HP = 256, Set this to 0 if you want to not take damage on squish
DEFAULT_PVP_SQUISH_DAMAGE = 0
DEFAULT_SQUISH_DURATION = 1 -- 1 Second
DEFAULT_RESTORE_DURATION = 0.5
DEFAULT_INVINCIBILITY_TIMER = 30 -- Equal to 1 second
DEFAULT_ARE_CUSTOM_MAPPINGS_ENABLED = true
DEFAULT_IS_AUTO_RESTORE_ENABLED = false
DEFAULT_EXPRESSION_OPTIONS = { 0, 1, 2, 6, 7, 8 } -- Blinking, Looking Forward, Lids Half Closed, Looking Up, Looking Down, X-Eyes

-- Constants
IS_LOGGING_ENABLED = false
DEFAULT_FALL_DAMAGE_THRESHOLD = 1536
ROTATED_MODEL_OFFSET = 5 -- This determines how far away the player should be when squished to a surface object, prevents clipping

-- Objects that squish the player upon contact
-- You can find a full list of object IDs at https://github.com/coop-deluxe/sm64coopdx/blob/main/docs/lua/guides/object-lists.md
SQUISH_ON_HIT_OBJECTS = {
    id_bhvBowlingBall,
    id_bhvPitBowlingBall,
    id_bhvFreeBowlingBall,
    id_bhvFallingPillarHitbox,
    id_bhvSnowmansBottom,
    id_bhvBigBoulder,
    id_bhvMadPiano,
    id_bhvWigglerHead,
    id_bhvWigglerBody
}

-- Objects that squish players upon contact as long as they have enough downward velocity
SQUISH_ON_VELOCITY_OBJECTS = {
    id_bhvBobomb,
    id_bhvBreakableBoxSmall,
    id_bhvChainChomp,
    id_bhvWaterBomb,
    id_bhvKingBobomb,
    id_bhvChuckya,
    id_bhvBigBullyWithMinions,
    id_bhvBigBully,
    id_bhvMrBlizzard,
    id_bhvGoomba
}

--- @type SettingsProfile
SETTINGS = {
    name = "",
    stickChance = DEFAULT_SURFACE_OBJECT_STICK_CHANCE,
    squishDepth = DEFAULT_SQUISH_DEPTH,
    spreadX = DEFAULT_SPREAD_X,
    spreadZ = DEFAULT_SPREAD_Z,
    soundVol = DEFAULT_SOUND_VOLUME,
    isSmearingEnabled = DEFAULT_IS_SMEAR_EFFECT_ENABLED,
    baseSquishDamage = DEFAULT_BASE_SQUISH_DAMAGE,
    pvpSquishDamage = DEFAULT_PVP_SQUISH_DAMAGE,
    squishDuration = DEFAULT_SQUISH_DURATION,
    invincTimer = DEFAULT_INVINCIBILITY_TIMER,
    isDPadEnabled = DEFAULT_ARE_CUSTOM_MAPPINGS_ENABLED,
    isAutoRestoreEnabled = DEFAULT_IS_AUTO_RESTORE_ENABLED,
    restoreDuration = DEFAULT_RESTORE_DURATION,
    expressionOptions = DEFAULT_EXPRESSION_OPTIONS
}
