-- name: Squish+
-- description: Squish+ v1.10\nBy \\#ff8cf2\\Jaygon\n\n\\#dcdcdc\\Squish+ expands on the existing squish feature in SM64, making it more dynamic, more interactive, and more cartoony!\n\nPlayers will find themselves squished into all kinds of fun poses beneath friends and foes alike!\n\nSquish+ adds new sound effects, new squish physics, and new enemy interactions that will leave players flatter than ever before!

-- Modifiable via Mod Menu
DEFAULT_SURFACE_OBJECT_STICK_CHANCE = 0.25 -- 25%
DEFAULT_SQUISH_DEPTH = 0.02 -- How flat the character should be. Going lower than 0.005 causes rubberbanding issues (0.005 - 0.12)
DEFAULT_SPREAD_X = 0.4 -- How much the player's spread value should increase by on the X-axis when squished (0.0 - 1.0, Low values start to shrink Mario's model)
DEFAULT_SPREAD_Z = 0.4 -- How much the player's spread value should increase by on the Z-axis when squished (0.0 - 1.0, Low values start to shrink Mario's model)
DEFAULT_SOUND_VOLUME = 1.2 -- How loud all the custom sound effects will be {0.0, 2.5}
DEFAULT_IS_SMEAR_EFFECT_ENABLED = true
DEFAULT_RANDOM_POSE_CHANCE = 0.25 -- 25%
DEFAULT_CEIL_FLUTTER_CHANCE = 0.33 -- 33%
DEFAULT_FLOOR_FLUTTER_CHANCE = 0.1 -- 10%
DEFAULT_DEATH_FLUTTER_CHANCE = 0.2 -- 20%
DEFAULT_FLUTTER_ANIM_SPEED = 1.0 -- Multiplier for how fast the flutter animation plays
DEFAULT_FLUTTER_SPAN = 400
DEFAULT_FLUTTER_WEIGHT = 100
DEFAULT_INITIAL_FLUTTER_HEIGHT = 300
DEFAULT_FLUTTER_SPREAD_LIMIT = 4 -- The number of times a player can be spread before losing the ability to flutter
DEFAULT_FLUTTER_PITCH_SHIFT = 0.10 -- How much the flutter sound frequency should move downwards with each flutter cycle
DEFAULT_FLUTTER_PITCH_TAPERING = 0.75 -- How low the flutter sound frequency must reach before it begins tapering off
DEFAULT_BASE_SQUISH_DAMAGE = 256 -- One sliver of HP = 256, Set this to 0 if you want to not take damage on squish
DEFAULT_PVP_SQUISH_DAMAGE = 0
DEFAULT_SQUISH_DURATION = 1 -- 1 Second
DEFAULT_RESTORE_DURATION = 0.5
DEFAULT_ARE_CUSTOM_MAPPINGS_ENABLED = true
DEFAULT_IS_AUTO_RESTORE_ENABLED = false
DEFAULT_ARE_SQUISH_ALERTS_ENABLED = true
DEFAULT_SHOULD_USE_CHARACTER_NAME = false
DEFAULT_ENEMIES_STAY_SQUISHED = true
DEFAULT_ARE_CUSTOM_ENEMIES_ENABLED = true
DEFAULT_DYNAMIC_SPREAD = true
DEFAULT_SPREAD_WIDTH = 0.4
DEFAULT_SPREAD_HEIGHT = 0.4
DEFAULT_SPREAD_VEL_IMPACT = 1.0
DEFAULT_SPREAD_WEIGHT_IMPACT = 1.0
DEFAULT_SPREAD_RANDOMNESS = 0.05
DEFAULT_SPREAD_TAPERING = -0.15
DEFAULT_EXPRESSION_OPTIONS = { 0, 1, 2, 6, 7, 8 } -- Blinking, Looking Forward, Lids Half Closed, Looking Up, Looking Down, X-Eyes
DEFAULT_SPLAT_SOUNDS = { 0, 1, 2, 3, 4 }
DEFAULT_RESTORE_SOUNDS = { 0, 1, 2, 3, 4, 5 }
DEFAULT_FLUTTER_SOUNDS = { 0, 1, 2 }

-- Constants
IS_LOGGING_ENABLED = false
FALL_DAMAGE_THRESHOLD = 1536
SQUISH_THRESHOLD = 0.10 -- The gap between the floor and ceiling for Mario to enter the ACT_FLATTENED state
ROTATED_MODEL_OFFSET = 5 -- This determines how far away the player should be when squished to a surface object, prevents clipping
FLUTTER_MULTIPLIER = 0.766 -- Determines how much of a difference there should be between one peak of the flutter to the next relative to the distance between peak and center
DJUI_ALERT_COLOR = "\\#f7f440\\"
DJUI_ENTITY_ALERT_COLOR = "\\#f5df1c\\"
UNIQUE_DIALOGUE_CHANCE = 40 -- 40% - How likely a generic enemy's unique squish alerts are to play instead of a randomly generated one
SENTIENT_UNIQUE_DIALOGUE_CHANCE = 28 -- 28% - How likely a sentient enemy's unique squish alerts are to play instead of a randomly generated one
BOSS_UNIQUE_DIALOGUE_CHANCE = 76 -- 76% - How likely a boss enemy's unique squish alerts are to play instead of a randomly generated one

-- Objects that squish the player upon contact
-- You can find a full list of object IDs at https://github.com/coop-deluxe/sm64coopdx/blob/main/docs/lua/guides/object-lists.md
SQUISH_ON_HIT_OBJECTS = {
    id_bhvBowlingBall,
    id_bhvPitBowlingBall,
    id_bhvFreeBowlingBall,
    id_bhvFallingPillarHitbox,
    id_bhvChainChomp,
    id_bhvSnowmansBottom,
    id_bhvBigBoulder,
    id_bhvMadPiano,
    id_bhvWigglerHead,
    id_bhvWigglerBody,
}

-- Objects that squish players upon contact as long as they have enough downward velocity
SQUISH_ON_VELOCITY_OBJECTS = {
    id_bhvBobomb,
    id_bhvBreakableBoxSmall,
    id_bhvWaterBomb,
    id_bhvKingBobomb,
    id_bhvChuckya,
    id_bhvBigBullyWithMinions,
    id_bhvBigBully,
    id_bhvMrBlizzard,
    id_bhvGoomba,
}

-- Actions that can cause wall squishes and the velocity required to squish the player
SQUISH_ON_IMPACT_WITH_WALL_ACTIONS = {
    [ACT_FORWARD_AIR_KB] = { minVel = 35 },
    [ACT_BACKWARD_AIR_KB] = { minVel = 35 },
    [ACT_HARD_FORWARD_AIR_KB] = { minVel = 35 },
    [ACT_HARD_BACKWARD_AIR_KB] = { minVel = 35 },
    [ACT_THROWN_FORWARD] = { minVel = 30 },
    [ACT_THROWN_BACKWARD] = { minVel = 30 },
    [ACT_BACKWARD_GROUND_KB] = { minVel = 20, validPrevActions = { ACT_RIDING_SHELL_FALL, ACT_RIDING_SHELL_GROUND } },
}

-- Actions that the player cannot be squished during. Used to prevent softlocks
INVALID_SQUISH_ACTIONS = {
    ACT_BUBBLED,
    ACT_IN_CANNON,
    ACT_TELEPORT_FADE_IN,
    ACT_TELEPORT_FADE_OUT,
    ACT_BBH_ENTER_JUMP,
    ACT_BBH_ENTER_SPIN,
    ACT_FALL_AFTER_STAR_GRAB,
    ACT_UNLOCKING_STAR_DOOR,
    ACT_UNLOCKING_KEY_DOOR,
    ACT_PULLING_DOOR,
    ACT_PUSHING_DOOR,
    ACT_READING_AUTOMATIC_DIALOG,
    ACT_WAITING_FOR_DIALOG,
    ACT_EXIT_LAND_SAVE_DIALOG,
    ACT_STAR_DANCE_WATER,
    ACT_STAR_DANCE_EXIT,
    ACT_STAR_DANCE_NO_EXIT,
    ACT_JUMBO_STAR_CUTSCENE,
}

--- @type SettingsProfile
SETTINGS = {
    name = "",
    stickChance = DEFAULT_SURFACE_OBJECT_STICK_CHANCE,
    squishDepth = DEFAULT_SQUISH_DEPTH,
    soundVol = DEFAULT_SOUND_VOLUME,
    isSmearingEnabled = DEFAULT_IS_SMEAR_EFFECT_ENABLED,
    randomPoseChance = DEFAULT_RANDOM_POSE_CHANCE,
    baseSquishDamage = DEFAULT_BASE_SQUISH_DAMAGE,
    pvpSquishDamage = DEFAULT_PVP_SQUISH_DAMAGE,
    squishDuration = DEFAULT_SQUISH_DURATION,
    ceilFlutterChance = DEFAULT_CEIL_FLUTTER_CHANCE,
    floorFlutterChance = DEFAULT_FLOOR_FLUTTER_CHANCE,
    deathFlutterChance = DEFAULT_DEATH_FLUTTER_CHANCE,
    flutterAnimSpeed = DEFAULT_FLUTTER_ANIM_SPEED,
    flutterSpan = DEFAULT_FLUTTER_SPAN,
    flutterWeight = DEFAULT_FLUTTER_WEIGHT,
    initialFlutterHeight = DEFAULT_INITIAL_FLUTTER_HEIGHT,
    flutterSpreadLimit = DEFAULT_FLUTTER_SPREAD_LIMIT,
    flutterPitchShift = DEFAULT_FLUTTER_PITCH_SHIFT,
    flutterPitchTapering = DEFAULT_FLUTTER_PITCH_TAPERING,
    isDPadEnabled = DEFAULT_ARE_CUSTOM_MAPPINGS_ENABLED,
    isAutoRestoreEnabled = DEFAULT_IS_AUTO_RESTORE_ENABLED,
    shouldEnemiesStaySquished = DEFAULT_ENEMIES_STAY_SQUISHED,
    areCustomEnemiesEnabled = DEFAULT_ARE_CUSTOM_ENEMIES_ENABLED,
    areSquishAlertsEnabled = DEFAULT_ARE_SQUISH_ALERTS_ENABLED,
    shouldAlertCharacterName = DEFAULT_SHOULD_USE_CHARACTER_NAME,
    restoreDuration = DEFAULT_RESTORE_DURATION,
    dynamicSpread = DEFAULT_DYNAMIC_SPREAD,
    spreadWidth = DEFAULT_SPREAD_WIDTH,
    spreadHeight = DEFAULT_SPREAD_HEIGHT,
    spreadVelImpact = DEFAULT_SPREAD_VEL_IMPACT,
    spreadWeightImpact = DEFAULT_SPREAD_WEIGHT_IMPACT,
    spreadRandomness = DEFAULT_SPREAD_RANDOMNESS,
    spreadTapering = DEFAULT_SPREAD_TAPERING,
    expressionOptions = DEFAULT_EXPRESSION_OPTIONS,
    splatSounds = DEFAULT_SPLAT_SOUNDS,
    restoreSounds = DEFAULT_RESTORE_SOUNDS,
    flutterSounds = DEFAULT_FLUTTER_SOUNDS,
}

gGlobalSyncTable.baseSquishDamage = SETTINGS.baseSquishDamage
gGlobalSyncTable.pvpSquishDamage = SETTINGS.pvpSquishDamage
gGlobalSyncTable.squishDuration = SETTINGS.squishDuration
gGlobalSyncTable.isDPadEnabled = SETTINGS.isDPadEnabled
gGlobalSyncTable.isAutoRestoreEnabled = SETTINGS.isAutoRestoreEnabled
gGlobalSyncTable.shouldEnemiesStaySquished = SETTINGS.shouldEnemiesStaySquished
gGlobalSyncTable.areCustomEnemiesEnabled = SETTINGS.areCustomEnemiesEnabled
gGlobalSyncTable.areSquishAlertsEnabled = SETTINGS.areSquishAlertsEnabled
gGlobalSyncTable.shouldAlertCharacterName = SETTINGS.shouldAlertCharacterName
