-- name: Squish+
-- description: Squish+ v1.0\nBy \\#ff8cf2\\Jaygon\n\n\\#dcdcdc\\Squish+ expands on the existing squish feature in SM64, making it more dynamic, more interactive, and more cartoony! Players can now find themselves squished into a variety of poses, all based on the pose they were in the moment they got squashed! This mod adds new sound effects, new squish physics, and new enemy interactions that will leave players flatter than ever before!

-- Load Audio Samples
SPLAT_SOUNDS = {
    audio_sample_load('splat_0.ogg'),
    audio_sample_load('splat_1.ogg'),
    audio_sample_load('splat_2.ogg'),
    audio_sample_load('splat_3.ogg')
}

RESTORE_SOUNDS = {
    audio_sample_load('restore_0.ogg')
}

-- Default Values (These are all modifiable in the Mod menu, but you're welcome to play around with these if you want to go out of the default bounds)
DEFAULT_SPREAD_X = 0.4 -- How much the player's spread value should increase by on the X-axis when squished (0.0 - 1.0, Low values start to shrink Mario's model)
DEFAULT_SPREAD_Z = 0.4 -- How much the player's spread value should increase by on the Z-axis when squished (0.0 - 1.0, Low values start to shrink Mario's model)
DEFAULT_SQUISH_DEPTH = 0.02 -- How flat the character should be. Going lower than 0.005 causes rubberbanding issues (0.005 - 0.12)
DEFAULT_SURFACE_OBJECT_STICK_CHANCE = 0.25 -- 25%
DEFAULT_SQUISH_LENGTH = 1 -- 1 Second
DEFAULT_EXPRESSION_OPTIONS = { 0, 1, 2, 6, 7, 8 } -- Blinking, Looking Forward, Lids Half Closed, Looking Up, Looking Down, X-Eyes
DEFAULT_CUSTOM_SOUNDS = true -- Enables / Disables Custom SFX

-- Constants
BASE_DAMAGE = 256 -- One sliver of HP = 256, Set this to 0 if you want to not take damage on squish
IS_LOGGING_ENABLED = false

-- Objects that squish the player upon contact
-- You can find a full list of object IDs at https://github.com/coop-deluxe/sm64coopdx/blob/main/docs/lua/guides/object-lists.md
SQUISH_ON_HIT_OBJECTS = {
    id_bhvBowlingBall,
    id_bhvPitBowlingBall,
    id_bhvFreeBowlingBall,
    id_bhvFallingPillarHitbox,
    id_bhvJrbSlidingBox,
    id_bhvSnowmansBottom,
    id_bhvBigBoulder,
    id_bhvMadPiano,
    id_bhvWigglerHead,
    id_bhvWigglerBody
}

-- Objects that squish players upon contact as long as they have enough downward velocity
SQUISH_ON_VELOCITY_OBJECTS = {
    id_bhvBobomb,
    id_bhvBreakableBoxSmall,
    id_bhvChainChomp,
    id_bhvWaterBomb,
    id_bhvKingBobomb,
    id_bhvChuckya,
    id_bhvBigBullyWithMinions,
    id_bhvMrBlizzard
}
