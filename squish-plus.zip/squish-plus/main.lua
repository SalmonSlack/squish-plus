-- name: Squish+
-- description: Squish+ v1.08.2\nBy \\#ff8cf2\\Jaygon\n\n\\#dcdcdc\\Squish+ expands on the existing squish feature in SM64, making it more dynamic, more interactive, and more cartoony! Players can now find themselves squished into a variety of poses, all based on the pose they were in the moment they got squashed! This mod adds new sound effects, new squish physics, and new enemy interactions that will leave players flatter than ever before!

local tostring, mod_file_exists, audio_sample_load = tostring, mod_file_exists, audio_sample_load
local AUDIO_EXTENSIONS = { '.ogg', '.mp3' }

---Loads audio samples into a table
---@param prefix string The prefix the files we're loading starts with
---@param len integer How many files to search through
---@return ModAudio[]
local function loadAudioSamples(prefix, len)
    local samples = {}
    for i = 0, len do
        local fileName = prefix .. "_" .. tostring(i)
        -- Checking file name against common audio extensions
        for j = 1, #AUDIO_EXTENSIONS do
            if mod_file_exists("sound/" .. fileName .. AUDIO_EXTENSIONS[j]) then
                local sample = audio_sample_load(fileName .. AUDIO_EXTENSIONS[j])
                table.insert(samples, sample)
                goto continue
            end
        end
        ::continue::
    end
    return samples
end

--- @type ModAudio[]
SPLAT_SOUNDS = loadAudioSamples("splat", 10)

--- @type ModAudio[]
RESTORE_SOUNDS = loadAudioSamples("restore", 10)

-- Modifiable via Mod Menu
DEFAULT_SURFACE_OBJECT_STICK_CHANCE = 0.25 -- 25%
DEFAULT_SQUISH_DEPTH = 0.02 -- How flat the character should be. Going lower than 0.005 causes rubberbanding issues (0.005 - 0.12)
DEFAULT_SPREAD_X = 0.4 -- How much the player's spread value should increase by on the X-axis when squished (0.0 - 1.0, Low values start to shrink Mario's model)
DEFAULT_SPREAD_Z = 0.4 -- How much the player's spread value should increase by on the Z-axis when squished (0.0 - 1.0, Low values start to shrink Mario's model)
DEFAULT_SOUND_VOLUME = 1.2 -- How loud all the custom sound effects will be {0.0, 2.5}
DEFAULT_IS_SMEAR_EFFECT_ENABLED = true
DEFAULT_RANDOM_POSE_CHANCE = 0.0 -- 0% Chance
DEFAULT_BASE_SQUISH_DAMAGE = 512 -- One sliver of HP = 256, Set this to 0 if you want to not take damage on squish
DEFAULT_PVP_SQUISH_DAMAGE = 0
DEFAULT_SQUISH_DURATION = 1 -- 1 Second
DEFAULT_RESTORE_DURATION = 0.5
DEFAULT_INVINCIBILITY_TIMER = 30 -- Equal to 1 second
DEFAULT_ARE_CUSTOM_MAPPINGS_ENABLED = true
DEFAULT_IS_AUTO_RESTORE_ENABLED = false
DEFAULT_ENEMIES_STAY_SQUISHED = true
DEFAULT_EXPRESSION_OPTIONS = { 0, 1, 2, 6, 7, 8 } -- Blinking, Looking Forward, Lids Half Closed, Looking Up, Looking Down, X-Eyes

-- Constants
IS_LOGGING_ENABLED = false
DEFAULT_FALL_DAMAGE_THRESHOLD = 1536
ROTATED_MODEL_OFFSET = 5 -- This determines how far away the player should be when squished to a surface object, prevents clipping

-- Objects that squish the player upon contact
-- You can find a full list of object IDs at https://github.com/coop-deluxe/sm64coopdx/blob/main/docs/lua/guides/object-lists.md
SQUISH_ON_HIT_OBJECTS = {
    id_bhvBowlingBall,
    id_bhvPitBowlingBall,
    id_bhvFreeBowlingBall,
    id_bhvFallingPillarHitbox,
    id_bhvSnowmansBottom,
    id_bhvBigBoulder,
    id_bhvMadPiano,
    id_bhvWigglerHead,
    id_bhvWigglerBody
}

-- Objects that squish players upon contact as long as they have enough downward velocity
SQUISH_ON_VELOCITY_OBJECTS = {
    id_bhvBobomb,
    id_bhvBreakableBoxSmall,
    id_bhvChainChomp,
    id_bhvWaterBomb,
    id_bhvKingBobomb,
    id_bhvChuckya,
    id_bhvBigBullyWithMinions,
    id_bhvBigBully,
    id_bhvMrBlizzard,
    id_bhvGoomba
}

-- Actions that can cause wall squishes and the velocity required to squish the player
SQUISH_ON_IMPACT_WITH_WALL_ACTIONS = {
    [ACT_FORWARD_AIR_KB] = { minVel = 35 },
    [ACT_BACKWARD_AIR_KB] = { minVel = 35 },
    [ACT_HARD_FORWARD_AIR_KB] = { minVel = 35 },
    [ACT_HARD_BACKWARD_AIR_KB] = { minVel = 35 },
    [ACT_THROWN_FORWARD] = { minVel = 30 },
    [ACT_THROWN_BACKWARD] = { minVel = 30 },
    [ACT_BACKWARD_GROUND_KB] = { minVel = 20, validPrevActions = { ACT_RIDING_SHELL_FALL, ACT_RIDING_SHELL_GROUND } },
}

INVALID_SQUISH_ACTIONS = {
    ACT_BUBBLED,
    ACT_IN_CANNON,
    ACT_TELEPORT_FADE_IN,
    ACT_TELEPORT_FADE_OUT,
    ACT_BBH_ENTER_JUMP,
    ACT_BBH_ENTER_SPIN,
    ACT_FALL_AFTER_STAR_GRAB,
    ACT_UNLOCKING_STAR_DOOR,
    ACT_UNLOCKING_KEY_DOOR,
    ACT_PULLING_DOOR,
    ACT_PUSHING_DOOR,
    ACT_READING_AUTOMATIC_DIALOG,
    ACT_WAITING_FOR_DIALOG,
    ACT_EXIT_LAND_SAVE_DIALOG,
    ACT_STAR_DANCE_WATER,
    ACT_STAR_DANCE_EXIT,
    ACT_STAR_DANCE_NO_EXIT,
    ACT_JUMBO_STAR_CUTSCENE,
}

--- @type SettingsProfile
SETTINGS = {
    name = "",
    stickChance = DEFAULT_SURFACE_OBJECT_STICK_CHANCE,
    squishDepth = DEFAULT_SQUISH_DEPTH,
    spreadX = DEFAULT_SPREAD_X,
    spreadZ = DEFAULT_SPREAD_Z,
    soundVol = DEFAULT_SOUND_VOLUME,
    isSmearingEnabled = DEFAULT_IS_SMEAR_EFFECT_ENABLED,
    randomPoseChance = DEFAULT_RANDOM_POSE_CHANCE,
    baseSquishDamage = DEFAULT_BASE_SQUISH_DAMAGE,
    pvpSquishDamage = DEFAULT_PVP_SQUISH_DAMAGE,
    squishDuration = DEFAULT_SQUISH_DURATION,
    invincTimer = DEFAULT_INVINCIBILITY_TIMER,
    isDPadEnabled = DEFAULT_ARE_CUSTOM_MAPPINGS_ENABLED,
    isAutoRestoreEnabled = DEFAULT_IS_AUTO_RESTORE_ENABLED,
    shouldEnemiesStaySquished = DEFAULT_ENEMIES_STAY_SQUISHED,
    restoreDuration = DEFAULT_RESTORE_DURATION,
    expressionOptions = DEFAULT_EXPRESSION_OPTIONS
}
